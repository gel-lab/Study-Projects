import random
import time

big_deck = [['lips', 'pencil', 'spider', 'exclamation point', 'scarecrow'],
            ['scarecrow', 'maple leaf', 'scissors', 'snowflake', 'dog'],
            ['pencil', 'maple leaf', 'apple', 'stop', 'tree'],
            ['lips', 'maple leaf', 'iglu', 'eye', 'tortoise'],
            ['pencil', 'scissors', 'iglu', 'dolphin', 'bomb'],
            ['scarecrow', 'tree', 'tortoise', 'dolphin', 'zebra'],
            ['scarecrow', 'stop', 'iglu', 'sun', 'snowman'],
            ['spider', 'scissors', 'tree', 'eye', 'sun'],
            ['pencil', 'dog', 'eye', 'zebra', 'snowman'],
            ['scarecrow', 'apple', 'eye', 'bomb', 'moon'],
            ['lips', 'dog', 'apple', 'dolphin', 'sun'],
            ['exclamation point', 'maple leaf', 'bomb', 'zebra', 'sun'],
            ['spider', 'maple leaf', 'dolphin', 'snowman', 'moon'],
            ['exclamation point', 'scissors', 'apple', 'tortoise', 'snowman'],
            ['lips', 'scissors', 'stop', 'zebra', 'moon'],
            ['spider', 'dog', 'stop', 'tortoise', 'bomb'],
            ['lips', 'snowflake', 'tree', 'bomb', 'snowman'],
            ['exclamation point', 'snowflake', 'stop', 'eye', 'dolphin'],
            ['exclamation point', 'dog', 'tree', 'iglu', 'moon'],
            ['pencil', 'snowflake', 'tortoise', 'sun', 'moon']]
small_deck = [['dolphin', 'bomb', 'spider'], ['eye', 'bomb', 'fire'],
              ['spider', 'fire', 'lock'], ['bomb', 'lock', 'tree']]
symbols = ['stop', 'exclamation point', 'maple leaf', 'bomb', 'moon', 'heart',
           'sun', 'iglu', 'pencil', 'scarecrow', 'spider', 'snowflake', 'dolphin', 'tortoise',
           'apple', 'treble clef', 'scissors', 'dog', 'zebra', 'tree', 'eye', 'lips', 'snowman']


# 1. Intersect two cards
def cards_intersect(card1, card2):
    in_both = []
    # check all the symbols in a list
    for i in range(len(card1)):
        if card1[i] in card2:
            in_both.append(card1[i])  # add list that include the intersection of the cards
    return in_both


# 2. Check if card is in deck and remove it
def remove_card(deck, card):
    # check all the cards in the deck
    for i in range(len(deck)):
        if len(card) == len(deck[i]):
            same = cards_intersect(deck[i], card)
            if len(same) == len(card):
                deck.remove(deck[i])  # delete the users card from the list' if its valid
                return True
    print('Error! card is not in the deck!')  # error output of not valid card
    return False


# 3. Check if new card matches and add it to the deck
def add_card(deck, card):
    # check all the cards in deck
    for i in range(len(deck)):
        # check the validity of the card's length
        if len(card) != len(deck[i]):
            print('Error! Card is of wrong length')  # error output if the card is longer than the excepted
            return False
        # make sure that there is only one same symbol between the user's card and the cards in the deck
        if len(cards_intersect(card, deck[i])) != 1:
            print('Error! number of matches for new card is not one')  # error output for more than one common symbol
            return False
    else:
        # add the card that the user want to add to the deck
        deck.append(card)
        return True


# 4. Check if a deck is valid
def is_valid(deck):
    # check all the cards in the deck
    for i in range(len(deck)):
        # check again all the cards in deck
        for j in range(i + 1, len(deck)):
            # check that the card's length is valid
            # make sure that there is only one same symbol between pair of cards in the deck
            if len(deck[0]) != len(deck[i]) or len(cards_intersect(deck[j], deck[i])) != 1:
                return False
            # make sure that list include only strings
            for a2 in deck[i]:
                if type(a2) != str:
                    return False
    return True


# 5. Draw 2 cards at random
def draw_random_cards(deck):
    # extra input assumptions
    if len(deck) >= 2:
        for i in range(len(deck)):
            if len(deck[0]) != len(deck[i]):
                return None
        for s1 in range(len(deck)):
            for s2 in (deck[s1]):
                if type(s2) != str:
                    return None
        # return two random and different cards from a list
        return random.sample(deck, 2)


# 6. Print all symbols with counts
def print_symbols_counts(deck):
    count = 0  # variable that counts analogy
    s_deck = []  # variable of empty list
    # check all the cards in the deck
    for card in deck:
        # check all the symbols in the card
        for symbol in card:
            s_deck.append(symbol)  # change the list of lists to one long list of strings (the symbols)
    s = set(s_deck)  # make a list without multiply of symbols
    n = list(s)  # return the set to a list type
    # check all the common symbols
    for i in n:
        # check all the symbols in the list and their multiply
        for j in s_deck:
            # check multiply of cards, and add it to the analog counter one by one
            if i == j:
                count += 1
        print(i, count)
        count = 0  # restart the analog counter in every loop


# 7. Interactive function for playing the game
def play_dobble(deck):
    card = []
    option = input('Select operation: (P)lay, (A)dd card, (R)emove card, or (C)ount\n')  # Get option from user
    # Check if new card matches and add it to the deck
    if option == 'A':
        card = input()
        card = card.split(",")
        add_card(deck, card)
    # Check if card is in deck and remove it
    elif option == 'R':
        card = input()
        card = card.split(",")
        remove_card(deck, card)
    # print all symbols with count
    elif option == 'C':
        print_symbols_counts(deck)
    # the option that start the game
    elif option == 'P':
        new_deck = deck[:]  # variable that represent the copy of the original deck
        c_correct = 0  # analog counting of the user's correct answers
        t_time = 0  # analog counting of the total time that took the user's to answer right
        w_result = 0  # analog counting of total wrong results
        # the game can continue all the time that the deck amount is bigger than two cards
        while len(new_deck) >= 2:
            print('Identify joint symbol:')  # out put that say to yhe user what to do
            # return two random and different cards from the deck
            card_sample = random.sample(new_deck, 2)
            print(*card_sample[0], sep=",")
            print(*card_sample[1], sep=",")
            start = time.time()  # starting time counting of the user's answer
            user_response = input()  # waiting for the users answer
            end = time.time()  # finish time counting of the user's answer
            sum_time = end - start
            # what happens if the user's answer is correct
            if user_response == cards_intersect(card_sample[0], card_sample[1])[0]:
                c_correct += 1
                t_time += sum_time
                print('Very nice! Found the correct card in', round(sum_time, 2), 'sec.')
            # what happens if the user's answer is wrong
            else:
                print('Wrong!')
                w_result += 1
            # removing of the cards that the user played with from the deck
            new_deck.remove(card_sample[0])
            new_deck.remove(card_sample[1])
        if t_time > 0:
            aver = round(t_time, 2) / c_correct
        # output for the user with all the details of his game performance
        else:
            aver = 0.0
        print('Finished Game. Correct:', c_correct, 'Wrong:', w_result, 'Average time:', aver, 'sec.')


# 8. Bonus question: create deck as large as possible
def create_deck(symbols, k):
    new_s = []  # variable of empty list
    # check all the symbols in the list symbol s
    for i in range(20):
        # return k random and different cards from a list
        new_card = random.sample(symbols, k)
        if len(new_s) == 0:
            new_s.append(new_card)  # add a card of five different symbols to the empty list
        else:
            for j in new_s:
                if len(cards_intersect(j, new_card)) != 1:
                    break
            new_s.append(new_card)
    return new_s


