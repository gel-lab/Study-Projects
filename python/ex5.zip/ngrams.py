import re


# helper function that return a string in the length of n
def word_length(w, n):
    if n >= len(w):
        return [w.lower()]
    small_words = "".join([l.lower() for l in w])
    words_attachment = []
    counting = 0
    counting_of_n = n
    the_loop = (len(w) - n + 1)

    for l in range(the_loop):
        words_attachment.append(small_words[counting:counting_of_n])
        counting += 1
        counting_of_n += 1
    for g in words_attachment:
        if len(g) != n:
            words_attachment.remove(g)
    return words_attachment


# helper function that clean the text from dots, spaces, commas and low alphabet
def text_validity(text, n):
    list_of_char = []
    good_text = (re.findall(r"[\w']+", text))
    for w in good_text:
        list_of_char.append(word_length(w, n))
    for lst in list_of_char:
        for g in lst:
            if len(g) != n:
                lst.remove(g)
    return list_of_char


# 1. Compute ngram statistics for text
def compute_ngram_frequency(text, n):
    # empty dictionary
    dict_counting = {}
    # variable of clean valid text
    pure_text = text_validity(text, n)
    # check all the valid words in the list
    for word in pure_text:
        # check all the strings in a word
        for string in word:
            # add and count the character to the empty dictionary when needed
            if string in dict_counting.keys():
                dict_counting[string] += 1
            else:
                dict_counting[string] = 1
    # sum of all the values that we count in the empty dictionary
    sum_of_values = sum([val for val in dict_counting.values()])
    # calculation of the relative prevalence of the characters in the text
    incidence_dict = {k: v / sum_of_values for k, v in dict_counting.items()}
    return incidence_dict



# 2. Concatenate items of dictionary to one string
def ngram_dict_to_string(d):
    # empty list
    incidence = []
    # all the keys and values of the d representing by pairs of tuples
    display_of_dict = d.items()
    # check akk the pairs in d.items, and append them to the empty list
    for k, v in display_of_dict:
        incidence.append("{}:{}".format(k, v))
    # variable of changing the values in the list to a string
    new_str = " ".join(incidence) + " "
    return new_str


# 3. split string to dictionary
def string_to_ngram_dict(s):
    # empty dictionary
    final_dictionary = {}
    # list of strings that demonstrate the keys and the value of the dictionary
    calm_display = s.split()
    # check all the imagined pairs of keys and values that represent as a string in the list
    for char in calm_display:
        i = char.split(":")
        # input them into the empty dictionary
        final_dictionary[i[0]] = float(i[1])
    return final_dictionary


# 4. Save to file
def write_ngram_dict(dict, filename):
    # change the inputted dict to a string by the second function
    text_dict = ngram_dict_to_string(dict)
    # open the file that we can get access to it
    the_file = open(filename + '.txt', "w")
    # writing to the file
    the_file.write(text_dict)
    the_file.close()


# # 5. Load from file
def read_ngram_dict(filename):
    # open the file that we can get access to it and than read it from the file
    with open(filename, 'r') as f:
        reading = f.read()
    # change the text that we red to a dictionary
    dict1 = string_to_ngram_dict(reading)
    return dict1

######################## Helper Functions ########################
