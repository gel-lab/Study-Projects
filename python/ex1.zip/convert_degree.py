# Helper function: Check if a string represents a real number
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def convert_degree(temp, units):

    if not is_number(temp):
        return None
    elif units == 'C' and float(temp) >= -273.15:
        return (float(temp) - 32) / (9 / 5)
    elif units == 'F' and float(temp) >= -469.67:
        return float(temp) * (9 / 5) + 32
    else:
        return None


def natural_language_convert_degree(user_request):
    x = user_request.split()
    if not is_number(x[3]):
        return None
    if x[2] == 'celsius' and float(x[3]) > -273.15:
        return float(x[3]), convert_degree(x[3], 'C')
    elif x[2] == 'fahreneit' and float(x[3]) > -469.67:
        return (float(x[3])), convert_degree(x[3], 'F')
    elif float(x[3]) < -273.15 or float(x[3]) < -469.67:
        return None


def user_input_convert_degree():
    enter_degrees = float(input('Please enter degrees: '))
    # wait for user response

    kind_of_units = str(input('Convert to (C)elsius, or (F)ahrenheit: '))
    # wait for user response

    if kind_of_units == 'C':
        print(str(enter_degrees) + ' in Fahrenheit is ' + str(convert_degree(enter_degrees, 'C')) + ' in Celsius')
    elif kind_of_units == 'F':
        print(str(enter_degrees) + ' in Celsius is ' + str(convert_degree(enter_degrees, 'F')) + ' in Fahrenheit')


# Helper function for determining state of matter from a real number representing the temperature
def water_temp_to_state(temp):
    t = temp
    t = float(t)
    if t <= 0:
        print('Solid')
    elif 0 < t < 100:
        print('Liquid')
    elif t >= 100:
        print('Gas')


# Convert water temperature to state of matter for user input.
def state_of_matter():
    a = int(input('please enter a number of temperatures (1-3): '))

    if a == 1:
        print('please enter the temperatures, one in each line')

        num1 = float(input())

        water_temp_to_state(num1)

    elif a == 2:

        print('please enter the temperatures, one in each line')

        num1 = float(input())
        num2 = float(input())

        water_temp_to_state(num1)
        water_temp_to_state(num2)

    elif a == 3:
        print('please enter the temperatures, one in each line')

        num1 = float(input())
        num2 = float(input())
        num3 = float(input())
        water_temp_to_state(num1)
        water_temp_to_state(num2)
        water_temp_to_state(num3)

    else:
        print('The number you entered is not between 1 and 3, goodbye!')
