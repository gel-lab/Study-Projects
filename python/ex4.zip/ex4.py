from sudoku_helper import sudoku_action


# 1. Check if board is complete
def sudoku_iscomplete(board):
    for check in board:  # check all the lists in the board
        for j in check:     # check all the variables in the list
            if j == 0:        # check if the little square is empty, and return False if it does
                return False
    return True


#  2. Return the 3*3 square covering x,y
def sudoku_square3x3(board, i, j):
    # variables of all the possible ranges
    i1 = 0 <= i <= 2
    i2 = 3 <= i <= 5
    i3 = 6 <= i <= 8
    j1 = 0 <= j <= 2
    j2 = 3 <= j <= 5
    j3 = 6 <= j <= 8
    # variables of all the squares in the sudoku board 9X9
    sq1 = [board[0][0:3], board[1][0:3], board[2][0:3]]
    sq2 = [board[0][3:6], board[1][3:6], board[2][3:6]]
    sq3 = [board[0][6:9], board[1][6:9], board[2][6:9]]
    sq4 = [board[3][0:3], board[4][0:3], board[5][0:3]]
    sq5 = [board[3][3:6], board[4][3:6], board[5][3:6]]
    sq6 = [board[3][6:9], board[4][6:9], board[5][6:9]]
    sq7 = [board[6][0:3], board[7][0:3], board[8][0:3]]
    sq8 = [board[6][3:6], board[7][3:6], board[8][3:6]]
    sq9 = [board[6][6:9], board[7][6:9], board[8][6:9]]
    # check if the ranges belong to a specific square 3X3, and return the accurate one.
    if i1 and j1:
        return sq1
    elif i1 and j2:
        return sq2
    elif i1 and j3:
        return sq3
    elif i2 and j1:
        return sq4
    elif i2 and j2:
        return sq5
    elif i2 and j3:
        return sq6
    elif i3 and j1:
        return sq7
    elif i3 and j2:
        return sq8
    elif i3 and j3:
        return sq9


# function that check all the conflicts in a row
def is_in_row(board, i, j):
    # variable of all the possible numbers
    relevant_numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9}
    conflict_num1 = []
    # check all the conflicts in a row
    # check all the variables in a row
    for k in range(len(board[i])):
        # check if a value in the relevant numbers and remove it from the set, but not if the square is not empty
        if board[i][k] in relevant_numbers and k != j:
            conflict_num1.append(board[i][k])
            relevant_numbers.remove(board[i][k])
    return relevant_numbers


# check all conflicts in column
def is_in_column(board, i, j):
    # variable of all the possible numbers
    relevant_numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9}
    new_column = []
    conflict_num2 = []
    for column in range(9):
        new_column.append(board[column][j])     # making a list of all the numbers in one column
    # check of all the values in the column
    for c in range(len(new_column)):
        # check if a value in the relevant numbers and remove it from the set, but not if the square is not empty
        if new_column[c] in relevant_numbers and c != i:
            relevant_numbers.remove(new_column[c])
            conflict_num2.append(new_column[c])
    return relevant_numbers


# check all the conflict in square 3X3
def is_in_square(board, i, j):
    # variable of all the possible numbers
    relevant_numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9}
    conflict_num3 = []
    counter = 0  # count how many ti,es there is a value in the square
    # check all the squares in the board 9X9
    for square in sudoku_square3x3(board, i, j):
        # check all the values in a square 3X3
        for conflict3 in square:
            if conflict3 == board[i][j]:
                counter += 1
            # check if a value in the relevant numbers and remove it , but not if the small square is not empty
            if conflict3 in relevant_numbers:
                conflict_num3.append(conflict3)
                relevant_numbers.remove(conflict3)
    if counter == 1:
        relevant_numbers.add(board[i][j])
    return relevant_numbers


# 3. Get available options of a position
def sudoku_options(board, i, j):
    # variables that include all the possible numbers in a row,column and square3X3
    row_ok, col_ok, square_ok = is_in_row(board, i, j), is_in_column(board, i, j), is_in_square(board, i, j)
    # variable that intersect all the possible numbers in a row,column and square3X3
    conflict_fix = row_ok & col_ok & square_ok
    relevant_numbers = []
    # check all the possible values to put in a specific small square
    for o in conflict_fix:
        # check if the value common for all the three checks and add it to a new list
        if o in row_ok and o in col_ok and o in square_ok:
            relevant_numbers.append(o)
    return set(relevant_numbers)


# 4. find all positions which have one option to fill
def find_all_unique(board):
    result = []
    # check all the lists index in board
    for u in range(len(board)):
        # check all the values index in list
        for c in range(len(board[u])):
            # check if the small square is empty
            if board[u][c] == 0:
                values_options = sudoku_options(board, u, c)
                # check that there is only one possible number to put
                if len(values_options) == 1:
                    result.append(tuple([u, c, values_options.pop()]))
    return result


# 5. Find squares with no option to fill
def find_all_conflicts(board):
    result = []
    # check all the lists index in board
    for u in range(len(board)):
        # check all the values index in list
        for c in range(len(board[u])):
            values_options = sudoku_options(board, u, c)
            # check that there is not possible values to fill in a small square
            if len(values_options) == 0:
                result.append(tuple([u, c]))
    return result


# 6. Add square:
def add_square(board, i, j, val):
    # check if a value is possible to put in a small square, and add it if it does
    if val in sudoku_options(board, i, j):
        board[i][j] = val
        return True
    # error message if its not possible to add a value
    print('Error! Value in conflict with current board')
    return False


# 7. Iteratively fill the board with unique options
def fill_board(board):
    # loop that run while there is position which have only one option to fill
    while len(find_all_unique(board)) != 0:
        # check all the lists index in the board
        for i in range(len(board)):
            # check all the values index in the list
            for j in range(len(board[i])):
                # check if the little square is empty
                if board[i][j] == 0:
                    options = sudoku_options(board, i, j)
                    # checking if there is one option exactly
                    if len(options) == 1:
                        # if it is, it add the value to the little square
                        board[i][j] = options.pop()
    # check if there are still little square without option to fill, and print error message if it happens
    if len(find_all_conflicts(board)) != 0:
        print('Error! current sudoku leads to inconsistencies. Must delete values')
        return False
    # check that all the little squares filled with a value
    elif sudoku_iscomplete(board):
        print('Success! sudoku solved')
        return True
    else:
        print('Sudoku partially solved')
        return True
