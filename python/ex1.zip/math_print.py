import math


def tan_30():
    print((math.tan(30*math.pi/180)))


def log_2019():
    print(math.log10(2019))


def circle_perimeter_3():
    print(math.pi * 2 * 3)


def circle_area_3():
    print((math.pi * (3 ** 2)))

