import turtle


# 1. Draw Mercedes car symbol
def draw_mercedes():
    turtle.circle(50)
    turtle.left(90)
    turtle.up()
    turtle.forward(50)
    turtle.down()
    turtle.forward(50)
    turtle.right(180)
    turtle.forward(50)
    turtle.right(60)
    turtle.forward(50)
    turtle.right(180)
    turtle.forward(50)
    turtle.right(60)
    turtle.forward(50)


# draw smiley
def draw_smiley():
    turtle.up()
    turtle.goto(-50, 0)
    turtle.down()
    turtle.circle(50)
    turtle.up()
    # the next lines draw the eyes
    turtle.goto(-70, 60)
    turtle.down()
    turtle.circle(10)
    turtle.up()
    turtle.goto(-30, 60)
    turtle.down()
    turtle.circle(10)
    turtle.up()
    turtle.goto(-70, 40)
    turtle.setheading(0)
    turtle.right(90)
    turtle.down()
    # this line draw the smile
    turtle.circle(20, 180)
    turtle.up()


# 3. Draw variable-length centipede with loop
def draw_centipede(n):
    draw_smiley()
    # the next lines draw the centipede's feelers
    turtle.up()
    turtle.goto(-25, 11 / 6 * 50)
    turtle.down()
    turtle.forward(25)
    turtle.up()
    turtle.goto(-75, 11 / 6 * 50)
    turtle.down()
    turtle.forward(25)
    turtle.up()
    # the next lines draw the centipede's body.
    for i in range(n):
        turtle.up()
        turtle.goto(50, 0)
        turtle.setheading(0)
        turtle.forward(100 * i)
        turtle.setheading(0)
        turtle.down()
        turtle.circle(50)
        turtle.up()
        turtle.goto((i + 1 / 4) * 100, -1 / 3 * 50)
        turtle.setheading(90)
        turtle.down()
        turtle.forward(25)
        turtle.up()
        turtle.goto((i + 3 / 4) * 100, -1 / 3 * 50)
        turtle.down()
        turtle.forward(25)
        turtle.up()


# 4. Draw polygon with n sides of length L
def draw_regular_polygon(n, L):
    n = int(n)
    L = float(L)
    polygon_angle = 360 / n
    for i in range(n):
        turtle.forward(L)
        turtle.right(polygon_angle)
    turtle.home()


# 5. Draw all pairwise lines between points
def connect_all_pairs(x, y):
    for i in range(len(x)):
        turtle.goto(x[i], y[i])
        for v in range(len(x)):
            turtle.goto(x[v], y[v])
            turtle.goto(x[v], y[v])
            turtle.up()

    turtle.done()



