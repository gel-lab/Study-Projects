from ngrams import *
import os


# helper function that check the length of the first value in a dictionary
def n_checker(d):
    n_len = list(d.keys())[0]
    return len(n_len)


# 6. Build an n-gram dictionary from text in a file
def build_language_model(language_filename, n, dict_filename=''):
    # check if the file is exist and return None if it isn't
    if not os.path.isfile(language_filename):
        return None
    # check if the file contain text, and return None if it isn't
    try:
        with open(language_filename, 'r') as text_check:
            exist = text_check.read()
    except:
        return None
    # dictionary with all the odds to get str in the text of the file in the length of n
    dict_of_chances = compute_ngram_frequency(exist, n)
    # check if the inputted value is default. if its not, its write the dictionary into the file
    if dict_filename != '':
        write_ngram_dict(dict_of_chances, dict_filename)
        return dict_of_chances
    else:
        return dict_of_chances


# 7. Compute distance between two dictionaries
def compute_ngram_distance(dict1, dict2):
    # empty list
    the_distances = []
    # check all the keys in the first inputted dictionary
    for k in dict1.keys():
        # check if the key is in the second inputted dictionary
        if k in dict2.keys():
            # if it does , it computes their distances , and save it in the empty list
            the_distances.append((dict1[k] - dict2[k]) ** 2)
        else:
            the_distances.append(dict1[k] ** 2)
    # sum of all the distances
    return sum(the_distances)


# 8. Reduce n-gram frequencies
def reduce_ngram(d, n):
    # empty list
    str_dict = []
    # check all the pairs of key and value in a dictionary, if its string type, it add it to the empty list
    for k, v in d.items():
        c = isinstance(k, str)
        z = isinstance(v, str)
        if c:
            str_dict.append(k)
        if z:
            str_dict.append(v)
    # check all the strings that we found in the dictionary
    for l in str_dict:
        # it prints error message if it find a shorter string length than the inputted n
        if n > len(l):
            print("Error! Current ngram size smaller than", [n])
            return False
    # empty dictionary
    new_dict1 = {}
    # check all the keys in the inputted dictionary
    for keys in d.keys():
        for key in word_length(keys, n)[0]:
            new_dict1[key] = 0
    for new_key in new_dict1.keys():
        for k, v in d.items():
            if new_key == k[:n]:
                new_dict1[new_key] += v
    return new_dict1


# 9. Build a language classifier
def classify_language(text_to_classify, list_of_dict_files):
    # empty dictionary
    get_dict = {}
    # empty list (will get the distances)
    distances_list = []
    # empty list(will get the values sizes)
    values_size = []
    # check all the text files in the list, and create with it the new empty dictionary
    for r in list_of_dict_files:
        get_dict[r] = read_ngram_dict(r)
    # check all the pairs of keys and values in the new dictionary
    for k, v in get_dict.items():
        # create a new list with all the first values sizes in the dictionaries
        values_size.append(n_checker(v))
    # finding the smallest value size
    min_it = min(values_size)
    # building a new n-gram from the inputted text and the smallest value size that we found
    new_dict = build_language_model(text_to_classify, min_it)
    # create a new list with all the distances between our new n-gram and the other inputted dictionaries
    for k in get_dict:
        distances_list.append(compute_ngram_distance(get_dict[k], new_dict))
    # valuable that find the index of the shortest distance in our new compuitings list
    index = distances_list.index(min(distances_list))
    # if there is smaller value, we reduce the n to the shortest that we can
    if distances_list.index(min(distances_list)) > min_it:
        reduce_ngram(new_dict, min_it)
        return index
    # if there is not smaller value, we return it's index
    else:
        return index

######################### Helper Functions #######################
